module.exports = async function (context, req) {
    context.res = {
        body: "Latency Test"
    };
};